import os
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Timo AI backend", version="1.0")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)

SYSTEM_PROMPT = """
Ты — Timo AI, русскоязычный помощник.
Отвечай понятно, доброжелательно и по существу.
Для школьных задач показывай ход решения и отдельно выделяй ответ.
Если не уверен, честно скажи об этом и не выдумывай факты.
Для важных вычислений проверяй результат альтернативным способом.
Не помогай обходить защиту чужих устройств, аккаунтов или сервисов.
Вместо этого объясняй официальные способы восстановления доступа.
"""

@app.get("/health")
async def health():
    return {"ok": True, "service": "Timo AI"}

@app.post("/chat")
async def chat(data: ChatRequest):
    base = os.getenv("AI_BASE_URL", "").rstrip("/")
    key = os.getenv("AI_API_KEY", "")
    model = os.getenv("AI_MODEL", "")
    if not base or not key or not model:
        raise HTTPException(status_code=503, detail="AI backend ещё не настроен.")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": data.message}
        ],
        "temperature": 0.3
    }
    try:
        async with httpx.AsyncClient(timeout=75) as client:
            response = await client.post(
                base + "/chat/completions",
                headers={"Authorization": f"Bearer {key}"},
                json=payload
            )
        response.raise_for_status()
        result = response.json()
        return {"reply": result["choices"][0]["message"]["content"]}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"AI provider error: {exc.response.status_code}")
    except Exception:
        raise HTTPException(status_code=502, detail="Не удалось получить ответ от AI-провайдера.")
