package com.timoai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TimoApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimoApp() {
    val messages = remember {
        mutableStateListOf(ChatMessage("Привет! Я Timo AI. Напиши вопрос — я постараюсь помочь.", false))
    }
    var input by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Укажи адрес своего AI-сервера в настройках.") }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("Timo AI")
                        Text("Интернет-ассистент • версия 1.0", style = MaterialTheme.typography.labelSmall)
                    } },
                    actions = {
                        IconButton(onClick = { showSettings = !showSettings }) {
                            Icon(Icons.Default.Settings, contentDescription = "Настройки")
                        }
                    }
                )
            },
            bottomBar = {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Спроси Timo AI…") }, maxLines = 4
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = input.isNotBlank() && !busy && serverUrl.startsWith("https://"),
                        onClick = {
                            val question = input.trim()
                            input = ""
                            messages.add(ChatMessage(question, true))
                            busy = true
                            status = "Timo AI думает…"
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) { sendToTimo(serverUrl, question) }
                                messages.add(ChatMessage(answer, false))
                                status = if (answer.startsWith("Ошибка:")) "Проверь подключение и адрес сервера." else "Готов к следующему вопросу."
                                busy = false
                            }
                        }
                    ) { Icon(Icons.Default.Send, contentDescription = "Отправить") }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (showSettings) {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Подключение к ИИ-серверу", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = serverUrl, onValueChange = { serverUrl = it.trim() },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("HTTPS-адрес сервера") }, singleLine = true
                            )
                            Text("Не вставляй сюда секретные API-ключи. Они должны храниться на сервере.",
                                style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = {
                                showSettings = false
                                status = if (serverUrl.startsWith("https://")) "Адрес принят на время работы приложения." else "Нужен HTTPS-адрес сервера."
                            }) { Text("Готово") }
                        }
                    }
                }
                Text(status, Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { message ->
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.widthIn(max = 320.dp)
                            ) {
                                Text(message.text, Modifier.padding(12.dp),
                                    color = if (message.fromUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun sendToTimo(baseUrl: String, question: String): String {
    if (!baseUrl.startsWith("https://")) return "Ошибка: введи корректный HTTPS-адрес сервера."
    return try {
        val client = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
        val body = JSONObject().put("message", question).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(baseUrl.trimEnd('/') + "/chat").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "Ошибка: сервер ответил кодом ${response.code}. $raw"
            else JSONObject(raw).optString("reply", "Сервер не вернул ответ.")
        }
    } catch (e: Exception) {
        "Ошибка: не удалось связаться с сервером. Проверь интернет и адрес."
    }
}
